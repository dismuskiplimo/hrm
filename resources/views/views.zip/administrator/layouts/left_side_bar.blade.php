<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- sidebar menu: : style can be found in sidebar.less -->
        @include('administrator.layouts.menu')
    </section>
    <!-- /.sidebar -->
</aside>